  /* #################################
     | SweetLink Core Script  lighfu |
     #################################
     
     License
     	All in License.txt
     
     credit
       creator  : lighfu (#29945)
       Website  : https://mydevelop.tyabo.com/Automate
       SweetLink: https://mydevelop.tyabo.com/Automate/Project/SweetLink
  */

  // Do not Change This Global Variable.
  // Reading "data" is safe.
  var init = 0;
  var initDB;
  var data = "";



  // 初期化(Web & Flow)
  SendInit();
  //InitMngr();

  //初期化マネージャ　(Automateから実行)... 初期化クエリを受け取ったら実行。
  function InitMngr() {
    document.getElementById('loading').style.display = "none";
    document.getElementById('content').style.display = "block";
    log("DB is Active.");
    log(data);
    // 応答確認後に確認用のインターバルを停止させる
    clearInterval(initDB);
    SendAutomate('init-end', 'OK');
  }



  function SendInit() {
    // スクリプトを更新する。
    var upd = "";
    setInterval(() => {
      ReloadDataScript("way.js");
      var recive = Automate2Web(); // 外部スクリプト
      var timestamp = recive["timestamp"];
      if (upd == "") upd = timestamp;
      if (upd != timestamp) {
        init = 1;
        data = recive["data"];
        if (recive["function"]) {
          // 関数が指定されたらそのまま実行。
          eval(recive["function"]);
        } else {
          // 追加予定 （関数の指定が無い場合）
        }
      }
      upd = timestamp;
    }, 200);

    if (init == 0) {
      // 初期設定を開始
      initDB = setInterval(() => {
        SendAutomate("init", "Check IndexedDB");
      }, 100);

    }
  }

  // スクリプトファイルを即座に再読み込みする
  function ReloadDataScript(src) {
    var head = document.getElementById('readscript');
    // 前のスクリプトを要素から削除。
    head.innerHTML = "";
    var script = document.createElement('script');
    // 最新のスクリプトファイルを読み込む。
    script.src = src + "?" + Date.now();
    // スクリプトタグ書き出し
    head.appendChild(script);
  }

  // Automate にテキスト(クエリ)を転送します。
  // 備考：結構なデータ量を転送できるはずだけど、
  // 念のために、512kb に制限してください。
  function SendAutomate(id, text) {
    log(text);
    WriteDB("n" + encodeURI(id), encodeURI(text));
    
    // Dep
    callbackSend(id,text);
  }

  function OrderAutomate(id, text) {
    log("Order:: " + id + "/" + text);
    WriteDB("o" + encodeURI(id), encodeURI(text));
  }



  // sweetDB としてデータベースを扱う。
  // (Automate側では、この書き込みを検知して内容を読み取ります。)
  function WriteDB(id, data) {
    var DBname = 'sweetDB';
    var DBversion = 1;
    var storeName = 'sugar';

    // sweetDB を初期化する。(おそらく以前のファイルが消去される。)
    (new Dexie(DBname)).delete();
    var db = new Dexie(DBname);

    // 規則を登録
    db.version(DBversion).stores({
      req: 'modif,ver,id,data'
    });

    // sweetDB に内容を書き込む。
    db.req.put({
      modif: "#lig#UUID%" + uuidV4() + "%#hfu#",
      ver: "project/SweetLink(1.0-beta4,20210328)",
      id: "#lig#ID%" + id + "%#hfu#",
      data: "#lig#DATA%" + data + "%#hfu#"
    });
  }

  // UUID v4 の(擬似)生成
  function uuidV4() {
    // https://github.com/GoogleChrome/chrome-platform-analytics/blob/master/src/internal/identifier.js
    // const FORMAT: string = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx";
    let chars = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".split("");
    for (let i = 0, len = chars.length; i < len; i++) {
      switch (chars[i]) {
        case "x":
          chars[i] = Math.floor(Math.random() * 16).toString(16);
          break;
        case "y":
          chars[i] = (Math.floor(Math.random() * 4) + 8).toString(16);
          break;
      }
    }
    return chars.join("");
  }


  // ログ表示。（表示していると安定性が低下する？）
  function log(str) {
    var d = new Date();
    if (1) document.getElementById('log').innerHTML = d.toISOString() + " >> " + str + "<br>" + document.getElementById('log').innerHTML;
  }