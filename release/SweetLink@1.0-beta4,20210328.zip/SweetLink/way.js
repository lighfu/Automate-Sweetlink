//  Content Sender Script  //
function Automate2Web(){
return {
              "timestamp": "1.620288654143E9",
              "function": "rt_battery()",
              "data": "72"
              }
}
// End Script //